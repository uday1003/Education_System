# education_system
----------------------------------------------------
https://drive.google.com/file/d/1_G1O5gNmBSzwI2zB-aj-oLvZQN306c0Y/view?usp=sharing
This is the link to the video explaining the project in detail.
--------------------------------------------------
